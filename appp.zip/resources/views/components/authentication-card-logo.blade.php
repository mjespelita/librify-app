<a href="/">
    <img src="{{ url('assets/logo.png') }}" alt="" width="200px">
</a>
