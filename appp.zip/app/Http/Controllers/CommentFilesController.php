<?php

namespace App\Http\Controllers;

use App\Models\CommentFiles;
use App\Http\Requests\StoreCommentFilesRequest;
use App\Http\Requests\UpdateCommentFilesRequest;

class CommentFilesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCommentFilesRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CommentFiles $commentFiles)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CommentFiles $commentFiles)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCommentFilesRequest $request, CommentFiles $commentFiles)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CommentFiles $commentFiles)
    {
        //
    }
}
