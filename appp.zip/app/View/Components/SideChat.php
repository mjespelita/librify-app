<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class SideChat extends Component
{
    /**
     * Create a new component instance.
     */

    public $chats;
    public function __construct($chats)
    {
        $this->chats = $chats;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.side-chat');
    }
}
