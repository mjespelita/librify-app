<?php $__env->startSection('content'); ?>
    <h1>Create a new musts</h1>

    <form action='<?php echo e(route('musts.store')); ?>' method='POST'>
        <?php echo csrf_field(); ?>
        
        <div class='form-group'>
            <label for='name'>Name</label>
            <input type='text' class='form-control' id='name' name='name' required>
        </div>
    
        <div class='form-group'>
            <label for='name'>Status</label>
            <input type='text' class='form-control' id='status' name='status' required>
        </div>
    
        <button type='submit' class='btn btn-primary mt-3'>Create</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\laramark\resources\views/musts/create-musts.blade.php ENDPATH**/ ?>