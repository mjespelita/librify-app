<?php $__env->startSection('content'); ?>
    <h1>Are you sure you want to delete this tasks?</h1>

    <form action='<?php echo e(route('tasks.destroy', $item->id)); ?>' method='GET'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type='submit' class='btn btn-danger'>Yes, Delete</button>
        <a href='<?php echo e(route('tasks.index')); ?>' class='btn btn-secondary'>Cancel</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\laramark\resources\views/tasks/delete-tasks.blade.php ENDPATH**/ ?>