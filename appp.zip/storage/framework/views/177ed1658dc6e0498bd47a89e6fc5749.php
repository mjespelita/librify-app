<?php $__env->startSection('content'); ?>
    <h1>Projects Details</h1>

    <div class="row">
        <div class="col-sm-12 col-md-4 col-lg-4">
            <div class='card'>
                <div class='card-body'>
                    <div class='table-responsive'>
                        <table class='table'>
                            
                            <tr>
                                <th>Name</th>
                                <td><?php echo e($item->name); ?></td>
                            </tr>
                        
                            <tr>
                                <th>Workspaces</th>
                                <td><a class="nav-link fw-bold text-primary" href="<?php echo e(url('show-workspaces/'.($item->workspaces->id ?? ''))); ?>"><?php echo e(($item->workspaces->name ?? "no data")); ?></a></td>
                            </tr>

                            <tr>
                                <th>Collaborators</th>
                                <td>
                                    <?php
                                        $displayedUsers = [];
                                    ?>

                                    <?php $__empty_1 = true; $__currentLoopData = App\Models\Taskassignments::where('tasks_projects_id', $item->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collaborator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if(!in_array($collaborator->users?->id, $displayedUsers)): ?>
                                            <img class="mb-2" src="<?php echo e($collaborator->users?->profile_photo_path ? url('/storage/' . $collaborator->users?->profile_photo_path) : '/assets/profile_photo_placeholder.png'); ?>" height="40" width="40" style="border-radius: 50%;" alt="User Profile Photo">
                                            <?php
                                                $displayedUsers[] = $collaborator->users?->id;
                                            ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <b>No Collaborators</b>
                                    <?php endif; ?>  
                                </td>
                            </tr>
            
                            <tr>
                                <th>Created At</th>
                                <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?></td>
                            </tr>
                            <tr>
                                <th>Updated At</th>
                                <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->updated_at)); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <div class='card'>
                <div class='card-body'>
                    <h5>Create a task</h5>
                    <form action='<?php echo e(route('tasks.store')); ?>' method='POST'>
                        <?php echo csrf_field(); ?>

                        <div class='form-group my-3'>
                            
                            <select id="ampmPicker" class="form-control" name="isScheduled">
                                <option value="0">Not - Scheduled</option>
                                <option value="1">Scheduled</option>
                            </select>
                        </div>
                        
                        <div class='form-group my-3'>
                            <label for='name'>Name</label>
                            <input type='text' class='form-control' id='name' name='name' required>
                        </div>
                    
                        <div class='form-group my-3'>
                            <label for='name'>Status</label>
                            <select name="status" class="form-control" id="">
                                <option value="pending">Pending</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>

                        <div class='form-group my-3 my-3'>
                            <label for='name'>Select Priority</label> <br> <br>
                            <input type='radio' id='priority' name='priority' value="low" checked> Low
                            <input type='radio' id='priority' name='priority' value="high"> High
                        </div>

                        
                        
                        <div class="calendar">
                            <div class="calendar-header">
                                <button type="button" class="btn btn-secondary prevMonth" >&#10094;</button>
                                <h2 id="month-year"></h2>
                                <button type="button" class="btn btn-secondary nextMonth" >&#10095;</button>
                            </div>
                            <div class="weekdays">
                                <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
                            </div>
                            <div class="days" id="calendar-days"></div>
                        </div>
                        
                        <div class="clock-container">
                            <label>Select Time:</label>
                            <div class="time-selector">
                                <select id="hourPicker"></select> :
                                <select id="minutePicker"></select>
                                <select id="ampmPicker">
                                    <option value="AM">AM</option>
                                    <option value="PM">PM</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class='form-group my-3'>
                            <input type='datetime-local' class='form-control deadline' hidden id='deadline' name='deadline' required>
                        </div>
                    
                        <div class='form-group my-3'>
                            
                            <input type='text' class='form-control' id='projects_id' value="<?php echo e($item->id); ?>" hidden name='projects_id' required>
                        </div>
                    
                        <div class='form-group my-3'>
                            
                            <input type='text' class='form-control' id='projects_workspaces_id' value="<?php echo e($item->workspaces->id ?? ''); ?>" hidden name='projects_workspaces_id' required>
                        </div>
            
                        <button type='submit' class='btn btn-primary mt-3'>Create</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-md-8 col-lg-8">
            <div class='card'>
                <div class='card-body'>
                    <h5>Tasks from <?php echo e($item->name); ?></h5>
                    <div class='row'>
                        <div class='col-lg-4 col-md-4 col-sm-12 mt-2'>
                            <div class='row'>
                                <div class='col-4'>
                                    <button type='button' class='btn btn-outline-secondary dropdown-toggle' data-bs-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                                        Action
                                    </button>
                                    <div class='dropdown-menu'>
                                        <a class='dropdown-item bulk-move-to-trash' href='#'>
                                            <i class='fa fa-trash'></i> Move to Trash
                                        </a>
                                        <a class='dropdown-item bulk-delete' href='#'>
                                            <i class='fa fa-trash'></i> <span class='text-danger'>Delete Permanently</span> <br> <small>(this action cannot be undone)</small>
                                        </a>
                                    </div>
                                </div>
                                <div class='col-8'>
                                    <form action='<?php echo e(url('/tasks-paginate')); ?>' method='get'>
                                        <div class='input-group'>
                                            <input type='number' name='paginate' class='form-control' placeholder='Paginate' value='<?php echo e(request()->get('paginate', 10)); ?>'>
                                            <div class='input-group-append'>
                                                <button class='btn btn-success' type='submit'><i class='fa fa-bars'></i></button>
                                            </div>
                                        </div>
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class='col-lg-4 col-md-4 col-sm-12 mt-2'>
                            <form action='<?php echo e(url('/tasks-filter')); ?>' method='get'>
                                <div class='input-group'>
                                    <input type='date' class='form-control' id='from' name='from' required> 
                                    <b class='pt-2'>- to -</b>
                                    <input type='date' class='form-control' id='to' name='to' required>
                                    <div class='input-group-append'>
                                        <button type='submit' class='btn btn-primary form-control'><i class='fas fa-filter'></i></button>
                                    </div>
                                </div>
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                        <div class='col-lg-4 col-md-4 col-sm-12 mt-2'>
                            <!-- Search Form -->
                            <form action='<?php echo e(url('/tasks-search')); ?>' method='GET'>
                                <div class='input-group'>
                                    <input type='text' name='search' value='<?php echo e(request()->get('search')); ?>' class='form-control' placeholder='Search...'>
                                    <div class='input-group-append'>
                                        <button class='btn btn-success' type='submit'><i class='fa fa-search'></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
        
                    <div class='table-responsive'>
                        <table class='table table-striped'>
                            

                            <tbody>
                                <?php
                                    $scheduledTasks = App\Models\Tasks::where('projects_id', $item->id)
                                        ->where('isScheduled', 1)
                                        ->orderBy('id', 'desc')
                                        ->paginate(10);

                                    $nonScheduledTasks = App\Models\Tasks::where('projects_id', $item->id)
                                        ->where('isScheduled', 0)
                                        ->orderBy('id', 'desc')
                                        ->paginate(10);
                                ?>

                                <br>

                                <b class="text-primary mt-5">Scheduled Tasks</b>
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope='col'>
                                                <input type='checkbox' name='' id='' class='checkAll'>
                                                </th>
                                            <th>Task Name</th>
                                            <th>Assigned Users</th>
                                            <th>Status</th>
                                            <th>Deadline</th>
                                            <th>Priority</th>
                                            <th>Scheduled</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $scheduledTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th scope='row'>
                                                    <input type='checkbox' class='check' data-id='<?php echo e($task->id); ?>'>
                                                </th>
                                                <td><?php echo e($task->name); ?></td>
                                                <td>
                                                    <?php $__empty_2 = true; $__currentLoopData = App\Models\Taskassignments::where('tasks_id', $task->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                        <img class="mb-2" src="<?php echo e($taskUser->users?->profile_photo_path ? url('/storage/' . $taskUser->users?->profile_photo_path) : '/assets/profile_photo_placeholder.png'); ?>" height="40" width="40" style="border-radius: 50%;" alt="User Profile Photo">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                        <b>No Assignees</b>
                                                    <?php endif; ?>    
                                                </td>
                                                <td>
                                                    <?php if($task->status === 'completed'): ?>
                                                        <b class="text-success"><i class="fas fa-check"></i></b>
                                                    <?php else: ?>
                                                        <b class="text-danger"><i class="fas fa-times"></i></b>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDay($task->deadline)); ?></td>
                                                <td>
                                                    <?php if($task->priority === 'high'): ?>
                                                        <b class="text-danger"><i class="fas fa-arrow-up"></i></b>
                                                    <?php else: ?>
                                                        <b class="text-primary"><i class="fas fa-arrow-down"></i></b>
                                                    <?php endif; ?>
                                                </td>
                                                <td><b class="text-success">Yes</b></td>
                                                <td>
                                                    <a href='<?php echo e(route('tasks.show', $task->id)); ?>'><i class='fas fa-eye text-success'></i></a>
                                                    <a href='<?php echo e(route('tasks.edit', $task->id)); ?>'><i class='fas fa-edit text-info'></i></a>
                                                    <a href='<?php echo e(route('tasks.delete', $task->id)); ?>'><i class='fas fa-trash text-danger'></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr><td colspan="8">No Scheduled Tasks...</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                                <b class="text-danger">Non-Scheduled Tasks</b>
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Task Name</th>
                                            <th>Assigned Users</th>
                                            <th>Status</th>
                                            <th>Deadline</th>
                                            <th>Priority</th>
                                            <th>Scheduled</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $nonScheduledTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th scope='row'>
                                                    <input type='checkbox' class='check' data-id='<?php echo e($task->id); ?>'>
                                                </th>
                                                <td><?php echo e($task->name); ?></td>
                                                <td>
                                                    <?php $__empty_2 = true; $__currentLoopData = App\Models\Taskassignments::where('tasks_id', $task->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                        <img class="mb-2" src="<?php echo e($taskUser->users?->profile_photo_path ? url('/storage/' . $taskUser->users?->profile_photo_path) : '/assets/profile_photo_placeholder.png'); ?>" height="40" width="40" style="border-radius: 50%;" alt="User Profile Photo">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                        <b>No Collaborators</b>
                                                    <?php endif; ?>    
                                                </td>
                                                <td>
                                                    <?php if($task->status === 'completed'): ?>
                                                        <b class="text-success"><i class="fas fa-check"></i></b>
                                                    <?php else: ?>
                                                        <b class="text-danger"><i class="fas fa-times"></i></b>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDay($task->deadline)); ?></td>
                                                <td>
                                                    <?php if($task->priority === 'high'): ?>
                                                        <b class="text-danger"><i class="fas fa-arrow-up"></i></b>
                                                    <?php else: ?>
                                                        <b class="text-primary"><i class="fas fa-arrow-down"></i></b>
                                                    <?php endif; ?>
                                                </td>
                                                <td><b class="text-danger">No</b></td>
                                                <td>
                                                    <a href='<?php echo e(route('tasks.show', $task->id)); ?>'><i class='fas fa-eye text-success'></i></a>
                                                    <a href='<?php echo e(route('tasks.edit', $task->id)); ?>'><i class='fas fa-edit text-info'></i></a>
                                                    <a href='<?php echo e(route('tasks.delete', $task->id)); ?>'><i class='fas fa-trash text-danger'></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr><td colspan="8">No Non-Scheduled Tasks...</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        
            <?php echo e(App\Models\Tasks::where('projects_id', $item->id)->orderBy('id', 'desc')->paginate(10)->links('pagination::bootstrap-5')); ?>

        
            <script src='<?php echo e(url('assets/jquery/jquery.min.js')); ?>'></script>
            <script>
                $(document).ready(function () {
        
                    // checkbox
        
                    var click = false;
                    $('.checkAll').on('click', function() {
                        $('.check').prop('checked', !click);
                        click = !click;
                        this.innerHTML = click ? 'Deselect' : 'Select';
                    });
        
                    $('.bulk-delete').click(function () {
                        let array = [];
                        $('.check:checked').each(function() {
                            array.push($(this).attr('data-id'));
                        });
        
                        $.post('/tasks-delete-all-bulk-data', {
                            ids: array,
                            _token: $("meta[name='csrf-token']").attr('content')
                        }, function (res) {
                            window.location.reload();
                        })
                    })
        
                    $('.bulk-move-to-trash').click(function () {
                        let array = [];
                        $('.check:checked').each(function() {
                            array.push($(this).attr('data-id'));
                        });
        
                        $.post('/tasks-move-to-trash-all-bulk-data', {
                            ids: array,
                            _token: $("meta[name='csrf-token']").attr('content')
                        }, function (res) {
                            window.location.reload();
                        })
                    })
                });
            </script>
        </div>
    </div>

    <a href='<?php echo e(route('projects.index')); ?>' class='btn btn-primary'>Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\InventoryManagemenrSystem\resources\views/projects/show-projects.blade.php ENDPATH**/ ?>