<?php $__env->startSection('content'); ?>
    <div class='row'>
        <div class='col-lg-6 col-md-6 col-sm-12'>
            <h1>All Tasks</h1>
        </div>
        <div class='col-lg-6 col-md-6 col-sm-12' style='text-align: right;'>
            <a href='<?php echo e(url('trash-tasks')); ?>'><button class='btn btn-danger'><i class='fas fa-trash'></i> Trash <span class='text-warning'><?php echo e(App\Models\Tasks::where('isTrash', '1')->count()); ?></span></button></a>
            
        </div>
    </div>
    
    <div class='card'>
        <div class='card-body'>
            <div class='row'>
                <div class='col-lg-4 col-md-4 col-sm-12 mt-2'>
                    <div class='row'>
                        <div class='col-4'>
                            <button type='button' class='btn btn-outline-secondary dropdown-toggle' data-bs-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                                Action
                            </button>
                            <div class='dropdown-menu'>
                                <a class='dropdown-item bulk-move-to-trash' href='#'>
                                    <i class='fa fa-trash'></i> Move to Trash
                                </a>
                                <a class='dropdown-item bulk-delete' href='#'>
                                    <i class='fa fa-trash'></i> <span class='text-danger'>Delete Permanently</span> <br> <small>(this action cannot be undone)</small>
                                </a>
                            </div>
                        </div>
                        <div class='col-8'>
                            <form action='<?php echo e(url('/tasks-paginate')); ?>' method='get'>
                                <div class='input-group'>
                                    <input type='number' name='paginate' class='form-control' placeholder='Paginate' value='<?php echo e(request()->get('paginate', 10)); ?>'>
                                    <div class='input-group-append'>
                                        <button class='btn btn-success' type='submit'><i class='fa fa-bars'></i></button>
                                    </div>
                                </div>
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
                <div class='col-lg-4 col-md-4 col-sm-12 mt-2'>
                    <form action='<?php echo e(url('/tasks-filter')); ?>' method='get'>
                        <div class='input-group'>
                            <input type='date' class='form-control' id='from' name='from' required> 
                            <b class='pt-2'>- to -</b>
                            <input type='date' class='form-control' id='to' name='to' required>
                            <div class='input-group-append'>
                                <button type='submit' class='btn btn-primary form-control'><i class='fas fa-filter'></i></button>
                            </div>
                        </div>
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                <div class='col-lg-4 col-md-4 col-sm-12 mt-2'>
                    <!-- Search Form -->
                    <form action='<?php echo e(url('/tasks-search')); ?>' method='GET'>
                        <div class='input-group'>
                            <input type='text' name='search' value='<?php echo e(request()->get('search')); ?>' class='form-control' placeholder='Search...'>
                            <div class='input-group-append'>
                                <button class='btn btn-success' type='submit'><i class='fa fa-search'></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <style>
                .task-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                    gap: 20px;
                    padding: 20px;
                }
            
                .task-card {
                    background: #fff;
                    border-radius: 8px;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                    padding: 15px;
                    display: flex;
                    flex-direction: column;
                    justify-content: space-between;
                    border-left: 5px solid #007bff;
                    transition: 0.3s;
                    position: relative;
                }
            
                .task-header {
                    font-weight: bold;
                    font-size: 18px;
                    margin-bottom: 10px;
                }
            
                .task-info {
                    font-size: 14px;
                    color: #666;
                    margin-bottom: 8px;
                }
            
                .task-assignees {
                    display: flex;
                    gap: 5px;
                    flex-wrap: wrap;
                    margin-bottom: 8px;
                }
            
                .task-assignees img {
                    height: 35px;
                    width: 35px;
                    border-radius: 50%;
                    border: 2px solid #ddd;
                }
            
                .task-status {
                    font-weight: bold;
                    padding: 5px 10px;
                    border-radius: 5px;
                    display: inline-block;
                    margin-bottom: 8px;
                }
            
                .task-status.completed {
                    background: #198754;
                    color: white;
                }
            
                .task-status.pending {
                    background: #DC3545;
                    color: white;
                }
            
                .task-actions {
                    display: flex;
                    justify-content: flex-end;
                    gap: 10px;
                    margin-top: auto;
                }
            
                .task-actions a {
                    text-decoration: none;
                    font-size: 18px;
                    color: #007bff;
                    transition: 0.3s;
                }
            
                .task-actions a:hover {
                    color: #0056b3;
                }
            </style>
            
            <div class="task-grid">
                <?php if(Auth::user()->role === "admin" || Auth::user()->role === "warehouse_admin" || Auth::user()->role === "office_admin"): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="task-card">
                            <div class="task-header">
                                <input type="checkbox" class="check" data-id="<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?>

                            </div>
            
                            <div style="display: flex; gap: 20px; padding: 15px; background-color: #f9f9f9; border-radius: 8px; font-family: Arial, sans-serif; font-size: 14px; align-items: center; flex-wrap: wrap;">

                                <div style="display: flex; align-items: center; gap: 6px;">
                                    <i class="fas fa-exclamation-circle" style="color: #e67e22;"></i>
                                    <span><strong>Priority:</strong>
                                        <span style="font-weight: bold; color: <?php echo e($item->priority === 'high' ? '#e74c3c' : '#2ecc71'); ?>;">
                                            <?php echo e(ucfirst($item->priority)); ?>

                                        </span>
                                    </span>
                                </div>
                            
                                <div style="display: flex; align-items: center; gap: 6px;">
                                    <i class="fas fa-clock" style="color: #3498db;"></i>
                                    <span><strong>Scheduled:</strong> <?php echo e($item->isScheduled ? 'Yes' : 'No'); ?></span>
                                </div>
                            
                                <div style="display: flex; align-items: center; gap: 6px;">
                                    <i class="fas fa-user-shield" style="color: #2ecc71;"></i>
                                    <span><strong>Audience:</strong> <?php echo e($item->isPrivate ? 'Private' : 'Public'); ?></span>
                                </div>
                            
                            </div>
                            

                            <hr>
                            

                            <div class="task-info">
                                <b>Project:</b> 
                                <a class="fw-bold text-primary" href="<?php echo e(url('show-projects/'.($item->projects->id ?? 'no-data'))); ?>">
                                    <?php echo e($item->projects->name ?? 'No Project'); ?>

                                </a>
                            </div>
            
                            <div class="task-info">
                                <b>Workspace:</b> 
                                <a class="fw-bold text-primary" href="<?php echo e(url('show-workspaces/'.($item->workspaces->id ?? 'no-data'))); ?>">
                                    <?php echo e($item->workspaces->name ?? 'No Workspace'); ?>

                                </a>
                            </div>

                            <div class="task-info">
                                <b>Created On:</b> 
                                <?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?>

                            </div>
            
                            <div class="task-info">
                                <b>Assignees:</b>
                                <div class="task-assignees">
                                    <?php $__empty_2 = true; $__currentLoopData = App\Models\Taskassignments::where('tasks_id', $item->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <a href="<?php echo e(url('show-technicians/'.$taskUser->users_id)); ?>"><img src="<?php echo e($taskUser->users?->profile_photo_path ? url('/storage/' . $taskUser->users->profile_photo_path) : '/assets/profile_photo_placeholder.png'); ?>" alt="User"></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span>No Assignees</span>
                                    <?php endif; ?>
                                </div>
                            </div>
            
                            <div class="task-status <?php echo e($item->status === 'completed' ? 'completed' : 'pending'); ?>">
                                <i class="fas <?php echo e($item->status === 'completed' ? 'fa-check' : 'fa-hourglass'); ?>"></i>
                                <?php echo e(ucfirst($item->status ?? 'No Status')); ?>

                            </div>
            
                            <div class="task-actions">
                                <a href="<?php echo e(route('tasks.show', $item->id)); ?>"><i class="fas fa-eye text-success"></i></a>
                                <a href="<?php echo e(route('tasks.edit', $item->id)); ?>"><i class="fas fa-edit text-info"></i></a>
                                <a href="<?php echo e(route('tasks.delete', $item->id)); ?>"><i class="fas fa-trash text-danger"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No Tasks Found</p>
                    <?php endif; ?>
                <?php endif; ?>
            
                <?php if(Auth::user()->role === "technician"): ?>
                    <?php $__empty_1 = true; $__currentLoopData = App\Models\Taskassignments::where('users_id', Auth::user()->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="task-card">
                            <div class="task-header">
                                <input type="checkbox" class="check" data-id="<?php echo e($item->tasks->id ?? ''); ?>">
                                <?php echo e($item->tasks->name ?? 'No Task'); ?>

                            </div>
            



                            <div class="task-info">
                                <b>Project:</b> 
                                <a class="fw-bold text-primary" href="<?php echo e(url('show-projects/'.($item->projects->id ?? 'no-data'))); ?>">
                                    <?php echo e($item->projects->name ?? 'No Project'); ?>

                                </a>
                            </div>
            
                            <div class="task-info">
                                <b>Workspace:</b> 
                                <a class="fw-bold text-primary" href="<?php echo e(url('show-workspaces/'.($item->workspaces->id ?? 'no-data'))); ?>">
                                    <?php echo e($item->workspaces->name ?? 'No Workspace'); ?>

                                </a>
                            </div>

                            <div class="task-info">
                                <b>Created On:</b> 
                                <?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?>

                            </div>
            
                            <div class="task-status <?php echo e($item->status === 'completed' ? 'completed' : 'pending'); ?>">
                                <i class="fas <?php echo e($item->status === 'completed' ? 'fa-check' : 'fa-hourglass'); ?>"></i>
                                <?php echo e(ucfirst($item->status ?? 'No Status')); ?>

                            </div>
            
                            <div class="task-actions">
                                <a href="<?php echo e(route('tasks.show', $item->tasks->id ?? '')); ?>"><i class="fas fa-eye text-success"></i></a>
                                <a href="<?php echo e(route('tasks.edit', $item->tasks->id ?? '')); ?>"><i class="fas fa-edit text-info"></i></a>
                                <a href="<?php echo e(route('tasks.delete', $item->tasks->id ?? '')); ?>"><i class="fas fa-trash text-danger"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No Tasks Found</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            
        </div>
    </div>

    <?php echo e($tasks->links('pagination::bootstrap-5')); ?>


    <script src='<?php echo e(url('assets/jquery/jquery.min.js')); ?>'></script>
    <script>
        $(document).ready(function () {

            // checkbox

            var click = false;
            $('.checkAll').on('click', function() {
                $('.check').prop('checked', !click);
                click = !click;
                this.innerHTML = click ? 'Deselect' : 'Select';
            });

            $('.bulk-delete').click(function () {
                let array = [];
                $('.check:checked').each(function() {
                    array.push($(this).attr('data-id'));
                });

                $.post('/tasks-delete-all-bulk-data', {
                    ids: array,
                    _token: $("meta[name='csrf-token']").attr('content')
                }, function (res) {
                    window.location.reload();
                })
            })

            $('.bulk-move-to-trash').click(function () {
                let array = [];
                $('.check:checked').each(function() {
                    array.push($(this).attr('data-id'));
                });

                $.post('/tasks-move-to-trash-all-bulk-data', {
                    ids: array,
                    _token: $("meta[name='csrf-token']").attr('content')
                }, function (res) {
                    window.location.reload();
                })
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\librify_app\resources\views/tasks/tasks.blade.php ENDPATH**/ ?>