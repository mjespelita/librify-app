<?php $__env->startSection('content'); ?>
    <div class='row'>
        <div class='col-lg-6 col-md-6 col-sm-12'>
            <h1>All Tasks</h1>
        </div>
        <div class='col-lg-6 col-md-6 col-sm-12' style='text-align: right;'>
            
            <input type="text" class="search-my-tasks form-control" placeholder="Search...">
        </div>
    </div>
    
    <div class='card'>
        <div class='card-body'>
             <div class='row'>
                
                <div class='col-lg-4 col-md-4 col-sm-12 mt-2'>
                    <h5>Jump To Date.</h5>
                    <form action='<?php echo e(url('/my-tasks-filter')); ?>' method='get'>
                        <div class='input-group'>
                            <input type='date' class='form-control' id='from' name='from' required> 
                            <b class='pt-2'>- to -</b>
                            <input type='date' class='form-control' id='to' name='to' required>
                            <div class='input-group-append'>
                                <button type='submit' class='btn btn-primary form-control'><i class='fas fa-filter'></i></button>
                            </div>
                        </div>
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                
            </div>

            <br>

            <h5>Today</h5>
            <div class='table-responsive'>
                <div class="task-grid">
                    <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $isEmpty = empty($item->tasks->name) || empty($item->tasks->status) ||
                                       empty($item->projects->name) || empty($item->workspaces->name);
                        ?>
                
                        <?php if(!$isEmpty): ?> 
                            <div class="task-card <?php echo e($item->tasks->status === 'completed' ? 'completed' : 'pending'); ?>">
                                <div class="task-header"><?php echo e($item->tasks->name ?? 'Untitled Task'); ?></div>
                
                                <div class="task-info">
                                    <b>Status:</b> <?php echo e(ucfirst($item->tasks->status ?? 'N/A')); ?>

                                </div>
                
                                <div class="task-info">
                                    <b>Project:</b> <?php echo e($item->projects->name ?? 'No Project'); ?>

                                </div>
                
                                <div class="task-info">
                                    <b>Workspace:</b> <?php echo e($item->workspaces->name ?? 'No Workspace'); ?>

                                </div>

                                <div class="task-info">
                                    <b>Created On:</b> <?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?>

                                </div>
                
                                <div class="task-actions">
                                    
                                    <div>
                                        <a href="<?php echo e(route('tasks.show', $item->tasks->id ?? '#')); ?>">
                                            <button class="btn btn-outline-secondary">
                                                <i class="fas fa-eye text-secondary"></i> View
                                            </button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No tasks found.</p>
                    <?php endif; ?>
                </div>
            </div>

            <?php echo e($tasks->links('pagination::bootstrap-5')); ?>


            <h5>Unfinished Tasks</h5>
            <div class='table-responsive'>
                <div class="task-grid">
                    <?php $__empty_1 = true; $__currentLoopData = $unfinished_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $isEmpty = empty($item->tasks->name) || empty($item->tasks->status) ||
                                       empty($item->projects->name) || empty($item->workspaces->name);
                        ?>
                
                        <?php if(!$isEmpty): ?> 
                            <div class="task-card <?php echo e($item->tasks->status === 'completed' ? 'completed' : 'pending'); ?>">
                                <div class="task-header"><?php echo e($item->tasks->name ?? 'Untitled Task'); ?></div>
                
                                <div class="task-info">
                                    <b>Status:</b> <?php echo e(ucfirst($item->tasks->status ?? 'N/A')); ?>

                                </div>
                
                                <div class="task-info">
                                    <b>Project:</b> <?php echo e($item->projects->name ?? 'No Project'); ?>

                                </div>
                
                                <div class="task-info">
                                    <b>Workspace:</b> <?php echo e($item->workspaces->name ?? 'No Workspace'); ?>

                                </div>

                                <div class="task-info">
                                    <b>Created On:</b> <?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?>

                                </div>
                
                                <div class="task-actions">
                                    
                                    <div>
                                        <a href="<?php echo e(route('tasks.show', $item->tasks->id ?? '#')); ?>">
                                            <button class="btn btn-outline-secondary">
                                                <i class="fas fa-eye text-secondary"></i> View
                                            </button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No tasks found.</p>
                    <?php endif; ?>
                </div>
            </div>

            <?php echo e($unfinished_tasks->links('pagination::bootstrap-5')); ?>


            <h5>Public Tasks</h5>
            <div class='table-responsive'>
                <div class="task-grid">
                    <?php $__empty_1 = true; $__currentLoopData = $public_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $isEmpty = empty($item->tasks->name) || empty($item->tasks->status) ||
                                       empty($item->projects->name) || empty($item->workspaces->name);
                        ?>
                
                        <?php if(!$isEmpty): ?> 
                            <div class="task-card <?php echo e($item->tasks->status === 'completed' ? 'completed' : 'pending'); ?>">
                                <div class="task-header"><?php echo e($item->tasks->name ?? 'Untitled Task'); ?></div>
                
                                <div class="task-info">
                                    <b>Status:</b> <?php echo e(ucfirst($item->tasks->status ?? 'N/A')); ?>

                                </div>
                
                                <div class="task-info">
                                    <b>Project:</b> <?php echo e($item->projects->name ?? 'No Project'); ?>

                                </div>
                
                                <div class="task-info">
                                    <b>Workspace:</b> <?php echo e($item->workspaces->name ?? 'No Workspace'); ?>

                                </div>

                                <div class="task-info">
                                    <b>Created On:</b> <?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?>

                                </div>
                
                                <div class="task-actions">
                                    
                                    <div>
                                        <a href="<?php echo e(route('tasks.show', $item->tasks->id ?? '#')); ?>">
                                            <button class="btn btn-outline-secondary">
                                                <i class="fas fa-eye text-secondary"></i> View
                                            </button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No tasks found.</p>
                    <?php endif; ?>
                </div>
            </div>

            <?php echo e($public_tasks->links('pagination::bootstrap-5')); ?>

        

    <script src='<?php echo e(url('assets/jquery/jquery.min.js')); ?>'></script>
    <script>
        $(document).ready(function () {

            // checkbox

            var click = false;
            $('.checkAll').on('click', function() {
                $('.check').prop('checked', !click);
                click = !click;
                this.innerHTML = click ? 'Deselect' : 'Select';
            });

            $('.bulk-delete').click(function () {
                let array = [];
                $('.check:checked').each(function() {
                    array.push($(this).attr('data-id'));
                });

                $.post('/tasks-delete-all-bulk-data', {
                    ids: array,
                    _token: $("meta[name='csrf-token']").attr('content')
                }, function (res) {
                    window.location.reload();
                })
            })

            $('.bulk-move-to-trash').click(function () {
                let array = [];
                $('.check:checked').each(function() {
                    array.push($(this).attr('data-id'));
                });

                $.post('/tasks-move-to-trash-all-bulk-data', {
                    ids: array,
                    _token: $("meta[name='csrf-token']").attr('content')
                }, function (res) {
                    window.location.reload();
                })
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u856365670/domains/librifyits.com/public_html/app/resources/views/technicians/my-tasks.blade.php ENDPATH**/ ?>