<?php $__env->startSection('content'); ?>
    <h1>Edit Logs</h1>

    <div class='card'>
        <div class='card-body'>
            <form action='<?php echo e(route('logs.update', $item->id)); ?>' method='POST'>
                <?php echo csrf_field(); ?>
                
        <div class='form-group'>
            <label for='name'>Log</label>
            <input type='text' class='form-control' id='log' name='log' value='<?php echo e($item->log); ?>' required>
        </div>
    
                <button type='submit' class='btn btn-primary mt-3'>Update</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\laramark\resources\views/logs/edit-logs.blade.php ENDPATH**/ ?>