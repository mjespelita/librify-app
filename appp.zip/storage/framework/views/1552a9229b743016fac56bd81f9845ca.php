<th <?php echo e($attributes->merge(['class' => 'text-xs text-gray-500 uppercase py-2 first:pl-3 last:pr-3 px-1 @sm:px-3 default:text-left'])); ?>>
    <?php echo e($slot); ?>

</th>
<?php /**PATH /home/u856365670/domains/librifyits.com/public_html/app/vendor/laravel/pulse/src/../resources/views/components/th.blade.php ENDPATH**/ ?>