<?php $__env->startSection('content'); ?>
    <h1>Onsites Details</h1>

    <div class='card'>
        <div class='card-body'>
            <div class='table-responsive'>
                <table class='table'>
                    <tr>
                        <th>ID</th>
                        <td><?php echo e($item->id); ?></td>
                    </tr>
                    
        <tr>
            <th>Items_id</th>
            <td><?php echo e($item->items_id); ?></td>
        </tr>
    
        <tr>
            <th>Items_types_id</th>
            <td><?php echo e($item->items_types_id); ?></td>
        </tr>
    
        <tr>
            <th>Technicians_id</th>
            <td><?php echo e($item->technicians_id); ?></td>
        </tr>
    
        <tr>
            <th>Quantity</th>
            <td><?php echo e($item->quantity); ?></td>
        </tr>
    
                    <tr>
                        <th>Created At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->updated_at)); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <a href='<?php echo e(route('onsites.index')); ?>' class='btn btn-primary'>Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\InventoryManagemenrSystem\resources\views/onsites/show-onsites.blade.php ENDPATH**/ ?>