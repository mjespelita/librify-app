<?php $__env->startSection('content'); ?>
    <h1>Are you sure you want to delete this damages?</h1>

    <form action='<?php echo e(route('damages.destroy', $item->id)); ?>' method='GET'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type='submit' class='btn btn-danger'>Yes, Delete</button>
        <a href='<?php echo e(route('damages.index')); ?>' class='btn btn-secondary'>Cancel</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\InventoryManagemenrSystem\resources\views/damages/delete-damages.blade.php ENDPATH**/ ?>